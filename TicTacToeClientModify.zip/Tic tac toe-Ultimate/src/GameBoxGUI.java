import java.awt.Color;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;

import javax.swing.event.MouseInputListener;

public class GameBoxGUI extends StdDraw implements MouseMotionListener, MouseInputListener {

	private TicTackToeULT ult;
	
	public GameBoxGUI(Color color) {
		super(color);
		
		ult = new TicTackToeULT();
	}

	@Override
	public void update(float deltaTime) {
		super.update(deltaTime);
		
		ult.update(deltaTime);
	}
	
	@Override
	public void render() {
		super.render();
		
		ult.render(graphicsRender);
		
		super.clear();
	}
	
	
	
	
	
	@Override
	public void mouseClicked(MouseEvent e) {
	}

	@Override
	public void mousePressed(MouseEvent e) {
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		ult.mouseReleased(e);
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		
	}

	@Override
	public void mouseDragged(MouseEvent e) {
		
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		ult.mouseMoved(e);
	}

}
