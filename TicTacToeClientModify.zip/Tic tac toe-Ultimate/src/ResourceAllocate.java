import java.util.ArrayList;

public class ResourceAllocate {

	public static ArrayList<WinLoss> checkWin(WinLoss[][] markers){
		ArrayList<WinLoss> match;
		
		for (int i = 0; i < Main.SIZE; i++) {
			int x = i % Main.ROWS;
			int y = i / Main.ROWS;
			
			
			match = checkMatch(x, y, 1, -1, i, markers);
			
			
			if(match == null) {
				match = checkMatch(x, y, 1, 1, i, markers);
			}

			
			if(match == null) {
				match = checkMatch(x, y, 1, 0, i, markers);
			}

			
			if(match == null) {
				match = checkMatch(x, y, 0, 1, i, markers);
			}
			
			if(match != null) {
				return match;
			}
		}
		
		return null;
	}
	
	private static ArrayList<WinLoss> checkMatch(int x, int y, int dX, int dY, int index, WinLoss[][] markers){
		ArrayList<WinLoss> match = new ArrayList<WinLoss>(Main.MATCH);
		int type = -1;
		int checkCount = 0;
		
		while(checkCount < Main.ROWS && index < Main.SIZE && x >= 0 && x <= Main.ROWS - 1 && 
				y >= 0 && y <= Main.ROWS - 1) {
			boolean found = false;
			WinLoss marker = markers[x][y];
			if(marker != null) {
				if(type == -1) {
					type = marker.getType();
				}
				
				if(marker.getType() == type) {
					match.add(marker);
					found = true;
				}
			}
			
			if(!found && match.size() < Main.MATCH) {
				match.clear();
				type = -1;
			}
			
			
			x += dX;
			y += dY;
			index ++;
			checkCount ++;
		}
		return match.size() >= Main.MATCH ? match : null;
	}

	public static int getWinType(WinLoss[][] markers) {
		ArrayList<WinLoss> match = checkWin(markers);

		return match == null ? -1 : match.get(0).getType();
	}
	
}
