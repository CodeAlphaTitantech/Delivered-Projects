import java.awt.Graphics2D;

public interface GrapbicOBJ {
	void update(float deltaTime);
	void render(Graphics2D graphicsRender);
}
