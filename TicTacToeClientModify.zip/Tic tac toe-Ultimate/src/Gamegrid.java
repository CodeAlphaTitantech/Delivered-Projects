import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

public class Gamegrid implements GrapbicOBJ {
	
	private ArrayList<BoxPlacement> placements = new ArrayList<BoxPlacement>(Main.SIZE);
	private ArrayList<WinLoss> winLine;
	private WinLoss[][] placer;
	
	private int gridThickness = 6;
	private int placementINDEX = 0;
	private int placementalpha = 0;
	
	private boolean gameEnd = false;
	private boolean isActive = true;
	
	private int winType = -1;
	
	private int x;
	private int y;
	
	private int xCordinate;
	private int yCordinate;
	
	private int size;
	
	private boolean gameGirddraw = true;
	private boolean gameActiveddraw = true;
	
	public Gamegrid(int x, int y, int size, boolean drawGrid, boolean drawActive) {
		this(x, y, size);
		
		this.gameGirddraw = drawGrid;
		this.gameActiveddraw = drawActive;
	}
	
	public Gamegrid(int x, int y, int size) {
		this.size = size;
		this.x = x;
		this.y = y;
		
		xCordinate = x * size;
		yCordinate = y * size;
		
		placer = new WinLoss[Main.ROWS][Main.ROWS];
		
		for (int i = 0; i < Main.SIZE; i++) {
			int xIndex = i % Main.ROWS;
			int yIndex = i / Main.ROWS;
			int cellSize = size / Main.ROWS;
			
			placements.add(new BoxPlacement(xCordinate + xIndex * cellSize, yCordinate + yIndex * cellSize, xIndex, yIndex, cellSize, cellSize));
		}
		
		reset();
	}

	@Override
	public void update(float deltaTime) {
		for (BoxPlacement placement : placements) {
			placement.update(deltaTime);
		}
		for (int x = 0; x < placer.length; x++) {
			for (int y = 0; y < placer.length; y++) {
				if(placer[x][y] == null) {
					continue;
				}
				
				placer[x][y].update(deltaTime);
			}
		}
	}

	@Override
	public void render(Graphics2D graphicsRender) {
		if(isActive && gameActiveddraw) {
			drawActiveBackground(graphicsRender);
		}
		
		for (BoxPlacement placement : placements) {
			placement.render(graphicsRender);
		}
		
		for (int x = 0; x < placer.length; x++) {
			for (int y = 0; y < placer.length; y++) {
				if(placer[x][y] == null) {
					continue;
				}
				
				placer[x][y].render(graphicsRender);
			}
		}
		
		if(gameGirddraw) {
			renderGrid(graphicsRender);
		}
	}

	private void drawActiveBackground(Graphics2D graphicsRender) {
		graphicsRender.setColor(new Color(0x305635));
		graphicsRender.fillRect(xCordinate, yCordinate, size, size);
		graphicsRender.setColor(Color.white);
	}

	private void renderGrid(Graphics2D graphicsRender) {
		graphicsRender.setColor(new Color(0x2e2e2e));
		
		int rowSize = size / Main.ROWS;
		for (int i = 0; i < Main.ROWS + 1; i++) {
			int thickness = gridThickness;
			if(i == 0 || i == Main.ROWS) {
				thickness *= 2;
			}
			graphicsRender.fillRect(xCordinate + i * rowSize - (thickness / 2), yCordinate, thickness, size);
			graphicsRender.fillRect(xCordinate, yCordinate + i * rowSize - (thickness / 2), size, thickness);
		}
		
		graphicsRender.setColor(Color.white);
		
		if(gameEnd) {
			
		}
	}

	public void mouseMoved(MouseEvent e) {
		if(!isActive) {
			return;
		}
		
		for (BoxPlacement placement : placements) {
			placement.checkCollision(e.getX(), e.getY() - 30);
		}
	}

	public BoxPlacement mouseReleased(MouseEvent e, int markerIndex) {
		setMarkerIndex(markerIndex);
		return mouseReleased(e);
	}

	public BoxPlacement mouseReleased(MouseEvent e) {
		for (BoxPlacement placement : placements) {
			if(placement.isActive()) {
				placement.set(true);
				
				int x = placement.getxIndex();
				int y = placement.getyIndex();
				placeMarker(x, y);
				return placement;
			}
		}
		
		return null;
	}

	public void placeMarker(int moveIndex) {
		placeMarker(moveIndex % Main.ROWS, moveIndex / Main.ROWS);
	}

	public void placeMarker(int x, int y, int markerIndex) {
		setMarkerIndex(markerIndex);
		placeMarker(x, y);
	}

	private void placeMarker(int x, int y) {
		placer[x][y] = new WinLoss(x, y, xCordinate, yCordinate, size, placementINDEX);
		
		placementINDEX ++;
		placementalpha ++;
		
		winLine = ResourceAllocate.checkWin(placer);
		
		if(winLine != null) {
			winLine.forEach(marker -> marker.setWon(true));
			winType = winLine.get(0).getType();
			gameEnd = true;
			
		} else if(placementalpha >= Main.SIZE) {
			gameEnd = true;
		}
	}
	
	public void reset() {
		for (int x = 0; x < placer.length; x++) {
			for (int y = 0; y < placer.length; y++) {
				placer[x][y] = null;
			}
		}
		

		for (BoxPlacement placement : placements) {
			placement.set(false);
		}
		
		gameEnd = false;
		winType = -1;
		placementINDEX = 0;
		placementalpha = 0;
		isActive = true;
	}
	
	public boolean isGameEnd() {
		return gameEnd;
	}

	public int getTurn() {
		return placementINDEX % 2;
	}

	public WinLoss[][] getMarkers() {
		return placer;
	}
	
	public int getWinner() {
		return winLine == null ? -1 : winLine.get(0).getType();
	}

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public boolean isActive() {
		return isActive;
	}
	
	public void setMarkerIndex(int markerIndex) {
		this.placementINDEX = markerIndex;
	}

}
