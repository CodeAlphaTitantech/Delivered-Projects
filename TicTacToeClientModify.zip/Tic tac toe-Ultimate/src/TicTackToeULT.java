import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

public class TicTackToeULT implements GrapbicOBJ {

	private ArrayList<Gamegrid> grids = new ArrayList<Gamegrid>(Main.SIZE);
	private Gamegrid mainGrid;
	private AlgoAPI ai;
	
	private int markerIndex = 0;
	
	public TicTackToeULT() {
		for (int i = 0; i < Main.SIZE; i++) {
			int x = i % Main.ROWS;
			int y = i / Main.ROWS;
			grids.add(new Gamegrid(x, y, Main.WIDTH / Main.ROWS));
		}
		
		mainGrid = new Gamegrid(0, 0, Main.WIDTH, false, false);
		
		ai = new AlgoAPI(mainGrid, this);
	}
	
	@Override
	public void update(float deltaTime) {
		for (Gamegrid grid : grids) {
			grid.update(deltaTime);
		}
		
		ai.update(deltaTime);
		mainGrid.update(deltaTime);
	}

	@Override
	public void render(Graphics2D graphicsRender) {
		for (Gamegrid grid : grids) {
			grid.render(graphicsRender);
		}
		
		mainGrid.render(graphicsRender);
		
		if(mainGrid.isGameEnd()) {
			drawEndGameOverlay(graphicsRender);
		}
	}
	


	private void drawEndGameOverlay(Graphics2D graphicsRender) {
		graphicsRender.setColor(new Color(0, 0, 0, (int)(225 * 0.5f)));
		
		graphicsRender.fillRect(0, 0, Main.WIDTH, Main.HEIGHT);
		graphicsRender.setColor(Color.white);
		
		int winType = mainGrid.getWinner();
		if(winType == -1) {
			
			graphicsRender.drawString(" Tied! ",  195, 235);
		} else {
			
			graphicsRender.drawString((winType == 0 ? "Player" : "CPU") + " has won!",  175, 235);
		}

		graphicsRender.drawString(" CLick Anywhere to Start Again. ",  85, 260);
		
	}

	public void mouseReleased(MouseEvent e) {
		if(ai.isMoving()) {
			return;
		}
		if(mainGrid.isGameEnd()) {
			reset();
			return;
		}
		int activeX = -1;
		int activeY = -1;
		for (Gamegrid grid : grids) {
			BoxPlacement selectedPlacement = grid.mouseReleased(e, markerIndex);
			if(selectedPlacement != null) {
				activeX = selectedPlacement.getxIndex();
				activeY = selectedPlacement.getyIndex();
				markerIndex ++;
				
				if(grid.getWinner() >= 0) {
					mainGrid.placeMarker(grid.getX(), grid.getY(), grid.getWinner());
				}
			}
		}
		
		boolean multipleGridsActive = setActiveGrid(activeX, activeY);
		
		if(markerIndex % 2 == 1) {
			// o turn for AI
			ai.makeMove(grids, multipleGridsActive, markerIndex);
			markerIndex++;
		}
	}
	
	public boolean setActiveGrid(int activeX, int activeY) {
		if(activeX >= 0 && activeY >= 0) {
			for (Gamegrid grid : grids) {
				if(grid.getX() == activeX && grid.getY() == activeY) {
					if(grid.isGameEnd()) {
						setGridsActive();
						return true;
					}
					
					grid.setActive(true);
				} else {
					grid.setActive(false);
				}
			}
		}
		
		return false;
	}

	private void setGridsActive() {
		for (Gamegrid grid : grids) {
			grid.setActive(!grid.isGameEnd());
		}
	}

	public void mouseMoved(MouseEvent e) {
		if(mainGrid.isGameEnd() || ai.isMoving()) {
			return;
		}
		for (Gamegrid grid : grids) {
			grid.mouseMoved(e);
		}
	}

	private void reset() {
		for (Gamegrid grid : grids) {
			grid.reset();
		}
		mainGrid.reset();
		markerIndex = 0;
	}

}
